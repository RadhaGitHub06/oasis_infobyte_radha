# educationWebsite
live view:
https://cinar00-education-website-html-css-js.netlify.app
